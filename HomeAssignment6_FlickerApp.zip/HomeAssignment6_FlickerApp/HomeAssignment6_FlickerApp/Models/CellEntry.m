//
//  CellEntry.m
//  HomeAssignment6_FlickerApp
//
//  Created by Student17 on 5/29/15.
//  Copyright (c) 2015 MentorMate. All rights reserved.
//

#import "CellEntry.h"

@implementation CellEntry

@end
