//
//  WebViewController.h
//  HomeAssignment6_FlickerApp
//
//  Created by Student17 on 5/28/15.
//  Copyright (c) 2015 MentorMate. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController
@property (nonatomic, strong) NSURL*currentURL;
@end
