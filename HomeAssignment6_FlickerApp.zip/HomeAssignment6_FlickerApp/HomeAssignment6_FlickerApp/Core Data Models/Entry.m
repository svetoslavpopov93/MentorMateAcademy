//
//  Entry.m
//  HomeAssignment6_FlickerApp
//
//  Created by Student17 on 5/26/15.
//  Copyright (c) 2015 MentorMate. All rights reserved.
//

#import "Entry.h"


@implementation Entry

@dynamic title;
@dynamic link;
@dynamic entryID;
@dynamic publishedDate;
@dynamic updatedDate;
@dynamic author;
@dynamic authorURL;
@dynamic authorIconURL;
@dynamic mainImageURL;

@end
