//
//  ViewController.h
//  HomeAssignment6_FlickerApp
//
//  Created by Student17 on 5/25/15.
//  Copyright (c) 2015 MentorMate. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Entry.h"
#import "DataManager.h"

@interface ViewController : UIViewController<NSXMLParserDelegate>


@end

