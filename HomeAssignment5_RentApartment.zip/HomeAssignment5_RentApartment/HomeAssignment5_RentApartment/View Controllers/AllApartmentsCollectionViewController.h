//
//  AllApartmentsCollectionViewController.h
//  HomeAssignment5_RentApartment
//
//  Created by svetoslavpopov on 5/14/15.
//  Copyright (c) 2015 svetoslavpopov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StateManager.h"
#import "AppDelegate.h"
#import "ApartmentCollectionViewCell.h"
#import "Apartment.h"

@interface AllApartmentsCollectionViewController : UICollectionViewController<NSFetchedResultsControllerDelegate>

@end
