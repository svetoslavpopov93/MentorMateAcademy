//
//  User.m
//  HomeAssignment5_RentApartment
//
//  Created by svetoslavpopov on 5/14/15.
//  Copyright (c) 2015 svetoslavpopov. All rights reserved.
//

#import "User.h"
#import "Apartment.h"
#import "Comment.h"


@implementation User

@dynamic firstName;
@dynamic lastName;
@dynamic nickName;
@dynamic address;
@dynamic age;
@dynamic password;
@dynamic apartments;
@dynamic comments;

@end
