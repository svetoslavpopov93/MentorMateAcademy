//
//  AddNewAlbumViewController.h
//  HomeAssignment3_AlbumOrganizer
//
//  Created by svetoslavpopov on 4/20/15.
//  Copyright (c) 2015 MentorMate. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataManagerSingleton.h"

@interface AddNewAlbumViewController : UIViewController

@end
